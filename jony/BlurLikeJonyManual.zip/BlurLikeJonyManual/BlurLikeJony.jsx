/*
	<javascriptresource>
	<name>Blur Like Jony</name>
	<menu>filter</menu>
	<category>bg-d</category>
	<about></about>
	<enableinfo>true</enableinfo>
    <enableinfo> in (PSHOP_ImageMode, RGBMode)  &amp;&amp;  (PSHOP_ImageDepth == 8) &amp;&amp;      (PSHOP_IsTargetVisible  &amp;&amp;  ! PSHOP_IsTargetSection)
    </enableinfo>
    </javascriptresource>    

*/
try {
  executeAction(stringIDToTypeID("f34f4ec8-4cbb-4633-8379-d5aac0d24c11"), undefined, DialogModes.ALL);	
} catch(e) { }